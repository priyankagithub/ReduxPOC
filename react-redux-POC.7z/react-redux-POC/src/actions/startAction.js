export const startAction = {
  type: "rotate",
  payload: true
};
